import { PrismaClient } from "@prisma/client"

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: process.env.DATA_BASE_URL,
  })

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma
}

